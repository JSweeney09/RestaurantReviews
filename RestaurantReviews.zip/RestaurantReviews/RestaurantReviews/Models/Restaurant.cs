﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace RestaurantReviews.Models
{
    public class Restaurant
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }

        public static Restaurant[] Restaurant_Select_ByCity(string City)
        {
            Restaurant[] objRestaurant = new Restaurant[10000];
            int i = 0;

            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.DB);
                SqlCommand comm = new SqlCommand("usp_Restaurant_SELECT_ByCity", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add(new SqlParameter("@City", City));
                try
                {
                    conn.Open();
                    SqlDataReader Reader = comm.ExecuteReader();
                    while (Reader.Read())
                    {
                        objRestaurant[i] = new Restaurant();
                        objRestaurant[i].Id = ((int)Reader["Id"]);
                        objRestaurant[i].Name = ((string)Reader["Name"]);
                        objRestaurant[i].City = ((string)Reader["City"]);
                        i++;
                    }
                    Reader.Close();
                }
                catch (Exception ex)
                {
                    Classes.oEventLog.WriteEvent("Restaurant - Restaurant_Select_ByCity - SQL", ex);
                }
                finally
                {
                    if (conn.State != ConnectionState.Closed)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                }

                return objRestaurant;
            }
            catch (Exception ex)
            {
                Classes.oEventLog.WriteEvent("Restaurant - Restaurant_Select_ByCity", ex);
                return objRestaurant;
            }
        }

        public static int Restaurant_Insert(Restaurant objRestaurant)
        {
            int intReturn = 0;

            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.DB);
                SqlCommand comm = new SqlCommand("usp_Restaurant_INSERT", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add(new SqlParameter("@Name", objRestaurant.Name));
                comm.Parameters.Add(new SqlParameter("@City", objRestaurant.City));
                try
                {
                    conn.Open();
                    SqlDataReader Reader = comm.ExecuteReader();
                    while (Reader.Read())
                    {
                        intReturn = ((int)Reader["intReturn"]);
                    }
                    Reader.Close();
                }
                catch (Exception ex)
                {
                    Classes.oEventLog.WriteEvent("Restaurant - Restaurant_Insert", ex);
                }
                finally
                {
                    if (conn.State != ConnectionState.Closed)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                }
                return intReturn;
            }
            catch (Exception ex)
            {
                Classes.oEventLog.WriteEvent("Restaurant - Restaurant_Insert", ex);

                return intReturn;
            }
        }
    }
}