﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace RestaurantReviews.Models
{
    public class Review
    {
        public int Id { get; set; }
        public int User_Id { get; set; }
        public int Restaurant_Id { get; set; }
        public string Description { get; set; }

        public static Review[] Review_Select_ByUser(int User_Id)
        {
            Review[] objReview = new Review[10000];
            int i = 0;

            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.DB);
                SqlCommand comm = new SqlCommand("usp_Review_SELECT_ByUser", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add(new SqlParameter("@User_Id", User_Id.ToString()));
                try
                {
                    conn.Open();
                    SqlDataReader Reader = comm.ExecuteReader();
                    while (Reader.Read())
                    {
                        objReview[i] = new Review();
                        objReview[i].Id = ((int)Reader["Id"]);
                        objReview[i].User_Id = ((int)Reader["User_Id"]);
                        objReview[i].Restaurant_Id = ((int)Reader["Restaurant_Id"]);
                        objReview[i].Description = ((string)Reader["Description"]);
                        i++;
                    }
                    Reader.Close();
                }
                catch (Exception ex)
                {
                    Classes.oEventLog.WriteEvent("Review - Review_Select_ByUser - SQL", ex);
                }
                finally
                {
                    if (conn.State != ConnectionState.Closed)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                }

                return objReview;
            }
            catch (Exception ex)
            {
                Classes.oEventLog.WriteEvent("Review - Review_Select_ByUser", ex);
                return objReview;
            }
        }

        public static int Review_Insert(Review objReview)
        {
            int intReturn = 0;

            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.DB);
                SqlCommand comm = new SqlCommand("usp_Review_INSERT", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add(new SqlParameter("@User_Id", objReview.User_Id.ToString()));
                comm.Parameters.Add(new SqlParameter("@Restaurant_Id", objReview.Restaurant_Id.ToString()));
                comm.Parameters.Add(new SqlParameter("@Description", objReview.Description));
                try
                {
                    conn.Open();
                    SqlDataReader Reader = comm.ExecuteReader();
                    while (Reader.Read())
                    {
                        intReturn = ((int)Reader["intReturn"]);
                    }
                    Reader.Close();
                }
                catch (Exception ex)
                {
                    Classes.oEventLog.WriteEvent("Review - Review_Insert", ex);
                }
                finally
                {
                    if (conn.State != ConnectionState.Closed)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                }
                return intReturn;
            }
            catch (Exception ex)
            {
                Classes.oEventLog.WriteEvent("Review - Review_Insert", ex);

                return intReturn;
            }
        }

        public static int Review_Delete(Review objReview)
        {
            int intReturn = 0;

            try
            {
                SqlConnection conn = new SqlConnection(Properties.Settings.Default.DB);
                SqlCommand comm = new SqlCommand("usp_Review_DELETE", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.Add(new SqlParameter("@Id", objReview.Id.ToString()));
                try
                {
                    conn.Open();
                    SqlDataReader Reader = comm.ExecuteReader();
                    while (Reader.Read())
                    {
                        intReturn = ((int)Reader["intReturn"]);
                    }
                    Reader.Close();
                }
                catch (Exception ex)
                {
                    Classes.oEventLog.WriteEvent("Review - Review_Delete - SQL", ex);
                }
                finally
                {
                    if (conn.State != ConnectionState.Closed)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                }
                return intReturn;
            }
            catch (Exception ex)
            {
                Classes.oEventLog.WriteEvent("Review - Review_Delete", ex);

                return intReturn;
            }
        }

    }

}