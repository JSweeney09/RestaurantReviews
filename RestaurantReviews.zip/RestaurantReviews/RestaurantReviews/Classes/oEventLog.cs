﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RestaurantReviews.Classes
{
    public class oEventLog
    {
        public enum EventType
        {
            ERROR = 0,
            WARNING = 1,
            TRACE = 2,
            INFO = 3
        }
        public static void WriteEvent(string strIdentity, EventType Type, string msg)
        {
            string _msg = "";

            switch (Type)
            {
                case EventType.ERROR:
                    _msg = "<font color='red'><b>[Event Type: " + Type.ToString() + "]</b></font>[" + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()
                        + "] - " + msg;
                    break;
                case EventType.INFO:
                    _msg = "<font color='blue'><b>[Event Type: " + Type.ToString() + "]</b></font>[" + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()
                        + "] - " + msg;
                    break;
                case EventType.TRACE:
                    _msg = "<font color='green'><b>[Event Type: " + Type.ToString() + "]</b></font>[" + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()
                        + "] - " + msg;
                    break;
                case EventType.WARNING:
                    _msg = "<font color='yellow'><b>[Event Type: " + Type.ToString() + "]</b></font>[" + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()
                        + "] - " + msg;
                    break;
            }

            if (_msg.Length > 0)
                RecordEvent(strIdentity, _msg);
        }
        public static void WriteEvent(string strIdentity, Exception ErrException)
        {
            string _msg = "";
            _msg = "<font color='red'><b>[Event Type: ERROR]</b></font>[" + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()
                + "] - Message: " + ErrException.Message +
                ", -- Stack: " + ErrException.StackTrace;
            RecordEvent(strIdentity, _msg);
        }
        static void RecordEvent(string strIdentity, string msg)
        {
            string strLogFiles = "C:\\RestaurantReviews";

            StreamWriter _Writer = null;
            string _FileName = strLogFiles + "\\Events\\EventLog" +
                DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() +
                DateTime.Now.Year.ToString() + ".html";

            try
            {
                if (!System.IO.Directory.Exists(strLogFiles + "\\Events"))
                    System.IO.Directory.CreateDirectory(strLogFiles + "\\Events");
            }
            catch { }

            try
            {
                _Writer = new StreamWriter(_FileName, true);
                _Writer.WriteLine("[IDENT:" + strIdentity + "] -- " + msg + "<br/>");
                _Writer.Close();
                _Writer = null;
            }
            catch
            {
                if (_Writer != null)
                {
                    try
                    {
                        _Writer.Close();
                    }
                    catch { }
                }
                _Writer = null;
            }
            finally
            {
                if (_Writer != null)
                {
                    try
                    {
                        _Writer.Close();
                    }
                    catch { }
                }
                _Writer = null;
            }
        }
    }
}