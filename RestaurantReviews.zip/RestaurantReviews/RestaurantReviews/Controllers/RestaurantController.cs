﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace RestaurantReviews.Controllers
{
    public class RestaurantController : ApiController
    {
        public IHttpActionResult SelectRestaurantByCity(string City)
        {
            // Step 1 - Get a list of restaurants by city

            Models.Restaurant[] objRestaurant = Models.Restaurant.Restaurant_Select_ByCity(City);
            return Ok(objRestaurant);
        }

    }
}
