﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace RestaurantReviews.Controllers
{
    public class ReviewController : ApiController
    {
        public IHttpActionResult PostReview(int Restaurant_Id, string Name, string City, int User_Id, string Review)
        {
            // Step 2 - Post a restaurant that is not in the database
            // Step 3 - Post a review for a restaurant

            // If Restaurant Id = 0, insert new Restuarant
            Models.Restaurant objRestaurant = new Models.Restaurant();
            objRestaurant.Name = Name;
            objRestaurant.City = City;
            if (Restaurant_Id == 0)
            {
                objRestaurant.Id = Models.Restaurant.Restaurant_Insert(objRestaurant);
            }
            else
            {
                objRestaurant.Id = Restaurant_Id;
            }

            Models.Review objReview = new Models.Review();
            objReview.Restaurant_Id = objRestaurant.Id;
            objReview.User_Id = User_Id;
            objReview.Description = Review;

            objReview.Id = Models.Review.Review_Insert(objReview);

            return Ok(objReview);
        }

        public IHttpActionResult SelectReviewByUser(int User_Id)
        {
            // Step 4 - Get of a list of reviews by user
            Models.Review[] objReview = Models.Review.Review_Select_ByUser(User_Id);
            return Ok(objReview);
        }

        public IHttpActionResult DeleteReview(int Review_Id)
        {
            // Step 5 - Delete a review
            Models.Review objReview = new Models.Review();
            objReview.Id = Review_Id;
            int intReturn;

            intReturn = Models.Review.Review_Delete(objReview);
            return Ok(intReturn);
        }

    }
}
